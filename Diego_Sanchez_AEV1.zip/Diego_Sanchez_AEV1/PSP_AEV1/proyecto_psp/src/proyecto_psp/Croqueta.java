package proyecto_psp;

public class Croqueta implements Runnable {

	String ingrediente;

	public Croqueta(String ingredient) {
		this.ingrediente = ingredient;

	}

	@Override
	public void run() {
		Croqueta c = new Croqueta(this.ingrediente);

		if (c.ingrediente.equals("BACALAO")) {
			try {
				System.out.println("---------------------------------------------");
				System.out.println("|                                           |");
				System.out.println("| INICIAMOS PREPARACION CROQUETA DE BACALAO |");
				System.out.println("|                                           |");
				Thread.sleep(3500);				
				System.out.println("|  --------------PREPARANDO--------------   |");
				Thread.sleep(3500);
				System.out.println("|                                           |");
				System.out.println("|       CROQUETA DE BACALAO ACABADA         |");
				System.out.println("|                                           |");
				System.out.println("---------------------------------------------");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (c.ingrediente.equals("QUESO")) {
			try {
				System.out.println("---------------------------------------------");
				System.out.println("|                                           |");
				System.out.println("|  INICIAMOS PREPARACION CROQUETA DE QUESO  |");
				System.out.println("|                                           |");
				Thread.sleep(4000);				
				System.out.println("|  --------------PREPARANDO--------------   |");
				Thread.sleep(4000);
				System.out.println("|                                           |");
				System.out.println("|        CROQUETA DE QUESO ACABADA          |");
				System.out.println("|                                           |");
				System.out.println("---------------------------------------------");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (c.ingrediente.equals("JAMON")) {
			try {
				System.out.println("---------------------------------------------");
				System.out.println("|                                           |");
				System.out.println("|  INICIAMOS PREPARACION CROQUETA DE JAMON  |");
				System.out.println("|                                           |");
				Thread.sleep(3000);				
				System.out.println("|  --------------PREPARANDO--------------   |");
				Thread.sleep(3000);
				System.out.println("|                                           |");
				System.out.println("|        CROQUETA DE JAMON ACABADA          |");
				System.out.println("|                                           |");
				System.out.println("---------------------------------------------");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (c.ingrediente.equals("POLLO")) {
			try {
				System.out.println("---------------------------------------------");
				System.out.println("|                                           |");
				System.out.println("|  INICIAMOS PREPARACION CROQUETA DE POLLO  |");
				System.out.println("|                                           |");
				Thread.sleep(2500);				
				System.out.println("|  --------------PREPARANDO--------------   |");
				Thread.sleep(2500);
				System.out.println("|                                           |");
				System.out.println("|        CROQUETA DE POLLO ACABADA          |");
				System.out.println("|                                           |");
				System.out.println("---------------------------------------------");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
