package proyecto_psp;

import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

public class procesadora {

	
	
	public static void main(String[] args) {
		long startTime = System.nanoTime();
		// TODO Auto-generated method stub
		int numBacalao = Integer.parseInt(args[0]);
		int numJamon = Integer.parseInt(args[1]);
		int numQueso = Integer.parseInt(args[2]);
		int numPollo = Integer.parseInt(args[3]);
		String priori = args[4];
		Thread orden; 
		System.out.println(priori);
		int priorinum = 4;
		if (priori.equals("BACALAO")) {
			priorinum = 1;
		}
		if (priori.equals("JAMON")) {
			priorinum = 2;
		}
		if (priori.equals("QUESO")) {
			priorinum = 3;
		}
		if (priori.equals("POLLO")) {
			priorinum = 4;
		}
		switch (priorinum) {
		case 1:
					for (int i = 0; i < numBacalao; i++) {
			Croqueta c = new Croqueta("BACALAO");
			orden= new Thread(c);
			orden.start();
			try{
				orden.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		for (int i = 0; i < numJamon; i++) {
			Croqueta c = new Croqueta("JAMON");
			orden= new Thread(c);
			orden.start();
			try {
				orden.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		for (int i = 0; i < numQueso; i++) {
			Croqueta c = new Croqueta("QUESO");
			orden= new Thread(c);
			orden.start();
			try {
				orden.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		for (int i = 0; i < numPollo; i++) {
			Croqueta c = new Croqueta("POLLO");
			orden= new Thread(c);
			orden.start();
			try {
				orden.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
			break;
		case 2:
			for (int i = 0; i < numJamon; i++) {
				Croqueta c = new Croqueta("JAMON");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			for (int i = 0; i < numBacalao; i++) {
				Croqueta c = new Croqueta("BACALAO");
				orden= new Thread(c);
				orden.start();
				try{
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			for (int i = 0; i < numQueso; i++) {
				Croqueta c = new Croqueta("QUESO");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			for (int i = 0; i < numPollo; i++) {
				Croqueta c = new Croqueta("POLLO");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			break;
		case 3:
			for (int i = 0; i < numQueso; i++) {
				Croqueta c = new Croqueta("QUESO");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			for (int i = 0; i < numBacalao; i++) {
				Croqueta c = new Croqueta("BACALAO");
				orden= new Thread(c);
				orden.start();
				try{
					orden.join();
				} catch (InterruptedException e) {
					
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			for (int i = 0; i < numJamon; i++) {
				Croqueta c = new Croqueta("JAMON");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			for (int i = 0; i < numPollo; i++) {
				Croqueta c = new Croqueta("POLLO");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			break;
		case 4:
			for (int i = 0; i < numPollo; i++) {
				Croqueta c = new Croqueta("POLLO");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			for (int i = 0; i < numBacalao; i++) {
				Croqueta c = new Croqueta("BACALAO");
				orden= new Thread(c);
				orden.start();
				try{
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			for (int i = 0; i < numJamon; i++) {
				Croqueta c = new Croqueta("JAMON");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			for (int i = 0; i < numQueso; i++) {
				Croqueta c = new Croqueta("QUESO");
				orden= new Thread(c);
				orden.start();
				try {
					orden.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			break;
		}


		long endTime   = System.nanoTime();
		
		long totalTime = endTime - startTime;
		long total = TimeUnit.SECONDS.convert(totalTime,TimeUnit.NANOSECONDS);
		JOptionPane.showMessageDialog(null, "CROQUETAS PREPARADAS EN : "+total+" segundos");

	}

}
