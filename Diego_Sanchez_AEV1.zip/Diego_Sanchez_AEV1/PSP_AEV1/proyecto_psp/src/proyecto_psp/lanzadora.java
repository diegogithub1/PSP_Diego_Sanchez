package proyecto_psp;

import java.awt.EventQueue;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JTextPane;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.border.BevelBorder;
import javax.swing.DefaultComboBoxModel;

public class lanzadora extends JFrame {

	private JPanel contentPane;
	private JTextField textBacalao;
	private JTextField textJamon;
	private JTextField textQueso;
	private JTextField textPollo;
	
	public static void lanzarProcesadora(String nBacalao,String nJamon,String nQueso,String nPollo,String prio) {

		try {

			String clase = "proyecto_psp.procesadora";
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classpath = System.getProperty("java.class.path");

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classpath);
			command.add(clase);
			command.add(nBacalao);
			command.add(nJamon);
			command.add(nQueso);
			command.add(nPollo);
			command.add(prio);
			

			
			
			ProcessBuilder builder = new ProcessBuilder(command);
			Process p = builder.inheritIO().start();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					lanzadora frame = new lanzadora();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public lanzadora() {
		setBackground(new Color(184, 237, 215));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 351, 235);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(238, 200, 119));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		textBacalao = new JTextField();
		textBacalao.setBorder(null);
		textBacalao.setForeground(new Color(0, 0, 0));
		textBacalao.setBounds(27, 49, 22, 22);
		textBacalao.setColumns(10);
		
		textJamon = new JTextField();
		textJamon.setBorder(null);
		textJamon.setBounds(27, 79, 22, 22);
		textJamon.setColumns(10);
		
		textQueso = new JTextField();
		textQueso.setBorder(null);
		textQueso.setBounds(27, 110, 22, 22);
		textQueso.setColumns(10);
		
		textPollo = new JTextField();
		textPollo.setBorder(null);
		textPollo.setBounds(27, 141, 22, 22);
		textPollo.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Bacalao");
		lblNewLabel.setBounds(55, 53, 50, 14);
		
		JLabel lblJamon = new JLabel("Jamon");
		lblJamon.setBounds(55, 82, 50, 14);
		
		JLabel lblQueso = new JLabel("Queso");
		lblQueso.setBounds(55, 113, 50, 14);
		
		JLabel lblPollo = new JLabel("Pollo");
		lblPollo.setBounds(55, 144, 50, 14);
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"","BACALAO" , "JAMON", "QUESO", "POLLO"}));
		
		JButton btnNewButton = new JButton("P E D I R");
		btnNewButton.setBorder(null);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 22));
		btnNewButton.setBounds(115, 49, 206, 67);
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				if(textBacalao.getText().equals("")) {	textBacalao.setText("0");}
				if(textJamon.getText().equals("")) {	textJamon.setText("0");}
				if(textQueso.getText().equals("")) {	textQueso.setText("0");}
				if(textPollo.getText().equals("")) {	textPollo.setText("0");}
			 lanzarProcesadora(textBacalao.getText(),textJamon.getText(),textQueso.getText(),textPollo.getText(),comboBox.getSelectedItem().toString());
			}
		});
		contentPane.setLayout(null);
		contentPane.add(lblJamon);
		contentPane.add(lblNewLabel);
		contentPane.add(lblPollo);
		contentPane.add(lblQueso);
		contentPane.add(textBacalao);
		contentPane.add(textJamon);
		contentPane.add(textQueso);
		contentPane.add(textPollo);
		contentPane.add(btnNewButton);
		contentPane.add(comboBox);
		JLabel lblNewLabel_1 = new JLabel("C R O Q U E T A S      D I E G O");
		lblNewLabel_1.setBackground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(9, 9, 319, 25);
		contentPane.add(lblNewLabel_1);
		

		
		
		comboBox.setBorder(null);
		comboBox.setBounds(215, 127, 106, 31);
		contentPane.add(comboBox);
		
		JLabel lblPRI = new JLabel("PRIORIDAD :");
		lblPRI.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPRI.setBounds(130, 129, 73, 27);
		contentPane.add(lblPRI);
	}
}
